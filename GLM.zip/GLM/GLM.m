%%%%%%%%%% GLM

% Prepare data
data_pre300 = [units_BLA_100; units_CA1_pre300];
data_pre200 = [units_BLA_100; units_CA1_pre200];
data_pre100 = [units_BLA_100; units_CA1_pre100];
data_100 = [units_BLA_100; units_CA1_100];
a = size(data_pre300, 2);

% GLM iterations
for m = 1:100  % Loop through 100 iterations
    
    % Split data into training and testing sets using random permutation
    k = randperm(a);
    train_idx = 1:round(a/2);
    test_idx = round(a/2) + 1:a;
    
    data_pre300_train = data_pre300(:, k(train_idx));
    data_pre300_test = data_pre300(:, k(test_idx));
    data_pre200_train = data_pre200(:, k(train_idx));
    data_pre200_test = data_pre200(:, k(test_idx));
    data_pre100_train = data_pre100(:, k(train_idx));
    data_pre100_test = data_pre100(:, k(test_idx));
    data_100_train = data_100(:, k(train_idx));
    data_100_test = data_100(:, k(test_idx));
    
    % Iterate over BLA units
    b = size(units_BLA_100, 1);
    for i = 1:b
        % Training data
        Xpre300_train = data_pre300_train(b+1:end, :);
        Xpre200_train = data_pre200_train(b+1:end, :);
        Xpre100_train = data_pre100_train(b+1:end, :);
        X100_train = data_100_train(b+1:end, :);
        Y_train = data_100_train(i, :);  % Current BLA unit as response
        
        % Fit GLM models (Poisson)
        GLM_pre300 = glmfit(Xpre300_train', Y_train', 'poisson');
        GLM_pre200 = glmfit(Xpre200_train', Y_train', 'poisson');
        GLM_pre100 = glmfit(Xpre100_train', Y_train', 'poisson');
        GLM_100 = glmfit(X100_train', Y_train', 'poisson');
        
        % Testing data
        Xpre300_test = data_pre300_test(b+1:end, :);
        Xpre200_test = data_pre200_test(b+1:end, :);
        Xpre100_test = data_pre100_test(b+1:end, :);
        X100_test = data_100_test(b+1:end, :);
        Y_test(:, i) = data_100_test(i, :)';
        
        % Predict using GLM models
        ypred_pre300(:, i) = glmval(GLM_pre300, Xpre300_test', 'log');
        ypred_pre200(:, i) = glmval(GLM_pre200, Xpre200_test', 'log');
        ypred_pre100(:, i) = glmval(GLM_pre100, Xpre100_test', 'log');
        ypred_100(:, i) = glmval(GLM_100, X100_test', 'log');
        
        % Calculate correlations
        Corr_pre300(i, m) = corr(ypred_pre300(:, i), Y_test(:, i));
        Corr_pre200(i, m) = corr(ypred_pre200(:, i), Y_test(:, i));
        Corr_pre100(i, m) = corr(ypred_pre100(:, i), Y_test(:, i));
        Corr_100(i, m) = corr(ypred_100(:, i), Y_test(:, i));
    end
end

% Calculate mean and standard deviation of correlations
mean_Corr_100 = mean(Corr_100, 2);
std_Corr_100 = std(Corr_100, 0, 2);

mean_Corr_pre100 = mean(Corr_pre100, 2);
std_Corr_pre100 = std(Corr_pre100, 0, 2);

mean_Corr_pre200 = mean(Corr_pre200, 2);
std_Corr_pre200 = std(Corr_pre200, 0, 2);

mean_Corr_pre300 = mean(Corr_pre300, 2);
std_Corr_pre300 = std(Corr_pre300, 0, 2);

% Combine data and standard deviations for plotting
data = [mean_Corr_100; mean_Corr_pre100; mean_Corr_pre200; mean_Corr_pre300]';
std_dev = [std_Corr_100; std_Corr_pre100; std_Corr_pre200; std_Corr_pre300]';

% Plot the mean correlations with error bars
figure;
bar(data, 'FaceColor', 'flat');
hold on;

% Define colors for the bars
colors = ['r','r','g','g','b','b','m','m',];

% Add error bars and color for each group
for i = 1:length(data)
    errorbar(i, data(i), std_dev(i), 'k.', 'LineWidth', 1.5);
    % Assign colors to the bars
    b = bar(i, data(i));
    b.FaceColor = colors(i);
end

% Set x-axis labels and other plot attributes
xticks(1:2:8);
xticklabels({'Corr 100', 'Corr pre100', 'Corr pre200', 'Corr pre300'});
ylabel("Correlation coefficient");
hold off;
